package test1;

import java.util.Date;

public class event {
 
  Date start;
  Date end;
  String name;
  int priority;
  int slot;
  String user;
  long days;
  int wait;
  
  public event(Date s,Date e,String n) {
	name =n;
	start =s;
	end = e;
  }
  
  public event(String n, int p, int s, String u, long d, int w)
  {
  name = n;
  priority = p;
  slot =s;
  user = u;
  days = d;
  wait = w;
  }
  
  
  
  //Prints attributes
  public void  print(){
	  System.out.println(name + "," + priority +"," + user + "," + slot);
	  //System.out.println(start);
	  //System.out.println(end);
	 
  }
  
  //Getters and Setters for all attributes
  
  public String getUser(){
	  return user;
  }
  public void setUser(String user){
	  this.user = user;
  }
  
  
  public long getDays(){
	  return days;
  }
  public void setDays(long days){
	  this.days = days;
  }
  
  public int getPriority(){
	  return slot;
  }
  public void setPriority(int priority){
	  this.priority = priority;
  }
  
public Date getStart() {
	return start;
}
public void setStart(Date start) {
	this.start = start;
}
public Date getEnd() {
	return end;
}
public void setEnd(Date end) {
	this.end = end;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSlot() {
	return slot;
}
public void setSlot(int slot) {
	this.slot = slot;
}
 
public int getWait(){
	  return wait;
}
public void setWait(int wait){
	  this.wait = wait;
}
}
