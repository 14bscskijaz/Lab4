package test1;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;




public class read {

	
	public List<event> list = new ArrayList<event>();
	public List<String[]> pdata = new ArrayList<String[]>();
	public List<event> events = new ArrayList<event>();
	
	
	
	
	public void load() {
// For Reading File
String filePath = "E:/csv/Academic _Schedule.csv";
String line = "";
String cvsSplitBy = ",";
BufferedReader br = null;
String buff[] = null;




DateFormat df = new SimpleDateFormat("mm/dd/yyyy");

try {

	br = new BufferedReader(new FileReader(filePath));
	line = br.readLine();
	
	while ((line = br.readLine()) != null) {
		buff  = line.split(cvsSplitBy);
	    list.add(new event(df.parse(buff[0]), df.parse(buff[1]), buff[2])); // stores object of an event in list
	
	}


//	Code to get unique events
/*	for(int i =0;i<list.size();i++)
	{
		match = false;
		String check= list.get(i).getName();
		for(int c = 0; c <unique.size();c++)
			{
			if(unique.get(c).equalsIgnoreCase(check))
			{
				match = true;
				break;
			}
		
		}
         if(match==false)
         {
        	 unique.add(check);
         }
        	 //System.out.println(list.get(i).getPriority());
	}
	for(int i = 0;i<unique.size();i++)
	{-
		System.out.println(unique.get(i));
		
	}*/
	
} catch (FileNotFoundException e){
e.printStackTrace();
} catch (IOException e) {
e.printStackTrace();
} catch (Exception e) {
System.out.println("Error");
} finally {
if (br != null) {
try {
br.close();
} catch (IOException e) {
e.printStackTrace();
}
}
}
}//Scanner UsrRsp = new Scanner(System.in);




public void ld_pr() {
	
		//For reading files
		String filePath1 = "E:/csv/jobs.csv";
		String line = "";
		String cvsSplitBy = ",";
		BufferedReader br = null;
		
		//For storing data each time
		String buff[] = null;
		
		
	
		
	try {
		
		br = new BufferedReader(new FileReader(filePath1));
		
		while ((line = br.readLine()) != null) {
			buff  = line.split(cvsSplitBy);
		    pdata.add(buff);
		}
		
		
		//Storing beginning of schedule
		Date begin = list.get(0).getStart();
		

		for(int i = 0 ; i <list.size();i++)
		{
			//System.out.println(pdata.get(i)[1]);
			for(int j =0; j<pdata.size();j++)
			{
				//Compares names and sets priority against them using priority table's csv file
				if(list.get(i).getName().equalsIgnoreCase(pdata.get(j)[0]))
					{
				    list.get(i).setPriority(Integer.parseInt(pdata.get(j)[2]));
					list.get(i).setUser(pdata.get(j)[1]);
					list.get(i).setSlot(Integer.parseInt(pdata.get(j)[3]));
					}
			}
			
			//Handling days
			//Storing number of days of an event 
			long diff = (list.get(i).getEnd().getTime()-list.get(i).getStart().getTime());
			long day = 1 +(diff / (24 * 60 * 60 * 1000));
			list.get(i).setDays(day);
			//System.out.println(list.get(i).getName() + ": "  +list.get(i).getDays());
			
			
			
			long dif = (list.get(i).getStart().getTime()-begin.getTime());
			long wait = (dif / (24 *60 * 60 * 1000)); 
			list.get(i).setWait((int) wait);
			System.out.println(list.get(i).getName() + ": "  +list.get(i).getWait());
			
}
		
		
		
		
		
		
	} catch (FileNotFoundException e){
	e.printStackTrace();
	} catch (IOException e) {
	e.printStackTrace();
	} catch (Exception e) {
	System.out.println("Error");
	} finally {
	if (br != null) {
	try {
	br.close();
	} catch (IOException e) {
	e.printStackTrace();
	}
	}
	}
}

//Scheduling events and allotting bandwidth
public void scheduler(){
	
	int wdays  = 0;
	int index = 0;
	int stud = 0;
	int fac = 0;
	int man = 0;
	
	  String name;
	  int priority;
	  int slot;
	  String user;
	  long days;
	  int wait;
	  
	
	while(wdays >740)
	for(int i = 0; i < list.size(); i ++)
	{
		
		if(list.get(i).getWait() == wdays)
		{
			name = list.get(i).getName();
			priority = list.get(i).getPriority();
			slot = list.get(i).getSlot();
			user = list.get(i).getUser();
			days = list.get(i).getDays();
			wait = list.get(i).getWait();
            events.add(new event(name,priority,slot,user,days,wait));
            }
			
		}
		wdays++;
		
		
	      int s_prio = 0;
		  int f_prio = 0;
	      int m_prio = 0;
	      double s_band = 0;
	      double f_band = 0;
	      double prod1 = 0;
	      double prod2= 0;
	      double tot = 0;
	      
		for(int i =0; i<events.size(); i++)
		{
			if(events.get(i).getUser().equalsIgnoreCase("s"))
			{
				s_prio += events.get(i).getPriority();
				
				stud++;
			}   
			else if (events.get(i).getUser().equalsIgnoreCase("f"))
			{
				f_prio += events.get(i).getPriority();
				fac++;
			}
			else 
			{
				m_prio = events.get(i).getPriority();
				man++;
			}
			
			events.get(i).setDays((events.get(i).getDays() - 1)); 
		}
	
	   //Calculating bandwidth
		prod1  = stud * s_prio;
		prod2 = fac * f_prio;
		tot = prod1 + prod2;
	
		for(int s = 0; s<4 ; s++)
		{
			//Students slot (12-6)
			if(s==1){
				s_band = (prod1/tot) *0.6 * 0.9;
				f_band = (prod2/tot) * 0.4 * 0.9;
			}
			
			//Faculty Slot (6-12)
			else if(s==2){
				s_band = (prod1/tot) *0.4 * 0.9;
				f_band = (prod2/tot) * 0.6 * 0.9;
				}
			//
			else if(s==3){
				
					s_band = (prod1/tot) *0.4 * 0.9;
					f_band = (prod2/tot) * 0.6 * 0.9;
				}
			else 
			{
					s_band = (prod1/tot) *0.4 * 0.9;
					f_band = (prod2/tot) * 0.6 * 0.9;
				}
			}
		}
	
	
	
}



	
	
