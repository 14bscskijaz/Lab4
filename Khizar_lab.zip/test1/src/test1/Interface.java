package test1;

public class Interface {

	
	
	public static void main(String[] args) {
		read rd = new read();
		read fl  = new read();
		rd.load();
		rd.ld_pr();
		rd.scheduler();

	}

}
